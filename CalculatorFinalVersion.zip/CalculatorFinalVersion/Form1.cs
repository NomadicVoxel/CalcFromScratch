﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorFinalVersion
{
    public partial class Form1 : Form
    {
        public Form1() { InitializeComponent(); }


        bool IsNewNum = true;
        string operation = " ";
        double input = 0;
        double runningTotal = 0;
        int formulaLength = 0;
        string log = "";

        private void InsertDigit(object sender, EventArgs e)
        {
            /* Insert Digit. 
             * It will simply add a digit,
             * or replace if I've indicated that it's time for a new number, 
             * by fetching the text of the button. 
             * I did have tags available, 
             * in case for some reason I made the stupid decision 
             * to have the buttons not indicate what they do :P
             */
            Button pressed = sender as Button;
            string input = pressed.Text;

            if (IsNewNum || txtTempValue.Text == "0")
            {
                txtTempValue.Text = "";
                IsNewNum = false;
            }
            txtTempValue.Text += input;
        }

        private void InsertDecimal(object sender, EventArgs e)
        {
            /* Insert Decimal
             * Simply adds a decimal point to the number, 
             * unless it detects that there's already one. 
             * In that case it just ignores it. 
             * Oh also it sets NewNumber to false 
             * so you can have numbers that are less than one. 
             */
            Button pressed = sender as Button;
            string input = pressed.Text;

            if (IsNewNum)
            {
                IsNewNum = false;
            }
            if (txtTempValue.Text.IndexOf(".") == -1)
            {
                txtTempValue.Text += input;
            }
        }

        private void Backspace(object sender, EventArgs e)
        {
            /* Backspace
             * Even if it seems longer and more complicated, it isn't. 
             * If there's something in the box, it removes it. 
             * If there isn't, it erases the logs too. 
             */
            if (IsNewNum)
            {
                txtTempValue.Text = "";
                txtLog.Text = "";
                log = "";
            }
            else if (txtTempValue.Text != "0")
            {//This side is simple backspace
                txtTempValue.Text = txtTempValue.Text.Remove(txtTempValue.Text.Length - 1);
                //That last line worked by shortening the number by one digit. 
                if (txtTempValue.Text.Length == 0)
                {
                    txtLog.Text = "";
                    txtTempValue.Text = "0";
                    //I decided that it needs to replace nothing with zero. 
                    // Huh. I subbed nought for nought. 
                }
                Update();
            }
            else
            {//and this is complete erasure
                txtLog.Text = "";
                runningTotal = 0;
                formulaLength = 0;
                log = "";
            }
        }

        private void PressOperator(object sender, EventArgs e)
        {
            /* Operations
             * First, it sets the flag for new numbers,
             * so when the user enters a new one it's replaced. 
             * Then it assembles the log,
             * if the formula has just started,
             * it'll pop in the first number too. 
             * When it has more complicated equations,
             * it'll call Calculate and show the results. 
             */
            IsNewNum = true;
            formulaLength++;
            input = Double.Parse(txtTempValue.Text.ToString());

            Button pressed = sender as Button;
            operation = pressed.Text;

            if (formulaLength == 1)
            {
                log = txtTempValue.Text;
                runningTotal = Double.Parse(txtTempValue.Text);
            }
            else
            {
                runningTotal = Double.Parse(txtTempValue.Text);
                if(!IsNewNum) Calculate();
            }

            txtLog.Text = log + operation;

        }

        private void HitEnter(object sender, EventArgs e)
        {
            if (formulaLength > 0)
            { //Simple, it updates the log and calculates.

                txtLog.Text = log + operation + txtTempValue.Text + "=";
                Calculate();
            }
            formulaLength = 0;
        }

        private void Calculate()
        {
            try
            {
                
                input = Double.Parse(txtTempValue.Text.ToString());
                /*Here, it feels I really could've used some efficiency things... but I'm not sure how.*/
                //Anyway, it should be obvious. If it's addition, total += input. 
                void adjustValue() { txtTempValue.Text = runningTotal.ToString(); }

                if (operation == "+")
                {
                    runningTotal = (runningTotal + input);
                    adjustValue();
                }
                if (operation == "*")
                {
                    runningTotal = (runningTotal * input);
                    adjustValue();
                }
                if (operation == "-")
                {
                    runningTotal = (runningTotal - input);
                    adjustValue();
                }

                if (operation == "/")
                { // Oddly, it didn't actually break when I tried to divide by zero. NAN is not good, but... no crash. 
                    if (input != 0)
                    {
                        runningTotal = (runningTotal / input);
                        adjustValue();
                    }
                    else
                    {
                        IsNewNum = true;
                        txtTempValue.Text = "(╯°□°）╯︵ ┻━┻";
                        txtLog.Text = "You cannot divide by zero.";
                    }
                }
                
            }
            catch
            {
                txtTempValue.Text = "LOLWUT";
                txtLog.Text = "Uh... I have no clue what broke but that was NOT GOOD.";
            }
            IsNewNum = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Focus();
        }

        private void KeyDown(object sender, KeyEventArgs e)
        {
            Clipboard.SetText(Clipboard.GetText() + "\n" + e.KeyCode.ToString());
            string k = e.KeyCode.ToString();
            if (k == "Divide") btnDivide.PerformClick();
            if (k == "Multiply") btnMultiply.PerformClick();
            if (k == "Subtract") btnSubtract.PerformClick();
            if (k == "NumPad7" || k == "Home") btn7.PerformClick();
            if (k == "NumPad8" || k == "Up") btn8.PerformClick();
            if (k == "NumPad9" || k == "PageUp") btn9.PerformClick();
            if (k == "Add") btnAdd.PerformClick();
            if (k == "NumPad4" || k == "Left") btn4.PerformClick();
            if (k == "NumPad5") btn5.PerformClick();
            if (k == "NumPad6" || k == "Right") btn6.PerformClick();
            if (k == "NumPad1" || k == "End") btn1.PerformClick();
            if (k == "NumPad2" || k == "Down") btn2.PerformClick();
            if (k == "NumPad3" || k == "Next") btn3.PerformClick();
            if (k == "Return") btnEqual.PerformClick();
            if (k == "NumPad0" || k == "Insert") btn0.PerformClick();
            if (k == "Decimal" || k == "Delete") btnDot.PerformClick();
        }
    }
}
